import React from 'react'
import { useParams } from 'react-router-dom';
const Contact = () => {
    const routeParams = useParams();
    // console.log(routeParams);
    return <div>Hi {routeParams.id}, Here are contact details</div>;
//return <div> <h1>  contact page </h1></div>
  };
export default Contact;